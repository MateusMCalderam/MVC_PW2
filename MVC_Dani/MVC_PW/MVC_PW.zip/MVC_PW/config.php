<?php

define("HOST", "localhost");
define("BASE", "trab_mvc");
define("USER", "root");
define("PASS", "");